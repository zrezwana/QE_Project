package com.perscholas.cucumber.step_definition;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;

import static org.junit.Assert.assertEquals;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@RunWith(Cucumber.class)
public class CucumberStepDef {
	private WebDriver driver;
	private Map<String, Object> vars;
	private JavascriptExecutor js;
	
	@Given("^the user navigates to the login page$")
	public void the_user_navigates_to_the_login_page() throws Throwable {
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\Student\\Downloads\\chromedriver_win32\\chromedriver.exe");
    	driver = new ChromeDriver();
    	js = (JavascriptExecutor) driver;
    	
    	driver.get("http://localhost:8080/hibernate_validation_dao/");
    	driver.manage().window().maximize();
    	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        
    }


    @When("^the user authenticates the login page$")
    public void the_user_authenticates_the_login_page() throws Throwable {
    	driver.findElement(By.id("username")).sendKeys("user1");
		driver.findElement(By.id("password")).sendKeys("pass1");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		String actual = driver.getTitle();
		System.out.println("Window Title" + actual);
		String expected = "SearchOptions";
		assertEquals(actual, expected);

		//driver.close();

        
    }

 @Then("^the application should display a homepage with two search options$")
 public void the_application_should_display_a_homepage_with_two_search_options() throws Throwable { 	 
	 String actual=driver.findElement(By.cssSelector("body > h1")).getText();
	 String expected="Hungry?";
	 assertEquals(actual,expected);
		driver.findElement(By.linkText("logout")).click(); 
	 //driver.close();
    	
    }
 
 @When("^the user clicks on the region search option $")
 public void the_user_clicks_on_the_region_search_option() throws Throwable {
	 driver.get("http:localhost:8080/hibernate_validation_dao/returnToSearch");
	 driver.findElement(By.cssSelector("body > a:nth-child(4)")).click();
	 driver.findElement(By.xpath("/html/body/div/a")).click();
     
 }

 @When("^the user clicks on the Bangladeshi region$")
 public void the_user_clicks_on_the_bangladeshi_region() throws Throwable {
     throw new PendingException();
 }

 @When("^the user can click checkout $")
 public void the_user_can_click_checkout() throws Throwable {
     throw new PendingException();
 }

 @Then("^the page will display a list of Regions$")
 public void the_page_will_display_a_list_of_regions() throws Throwable {
     throw new PendingException();
 }

 @Then("^the application should display a list of Bangladeshi food items$")
 public void the_application_should_display_a_list_of_bangladeshi_food_items() throws Throwable {
     throw new PendingException();
 }

 @Then("^the user can add a food item to the cart$")
 public void the_user_can_add_a_food_item_to_the_cart() throws Throwable {
     throw new PendingException();
 }

 @Then("^the user can view cart to increase quantity by 1 $")
 public void the_user_can_view_cart_to_increase_quantity_by_1() throws Throwable {
     throw new PendingException();
 }

 @Then("^the application will display the order confirmation page$")
 public void the_application_will_display_the_order_confirmation_page() throws Throwable {
     throw new PendingException();
 }

 @And("^the user can click logout$")
 public void the_user_can_click_logout() throws Throwable {
     throw new PendingException();
 }

}


