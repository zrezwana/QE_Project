package com.perscholas.com.SeleniumTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTests {
		private WebDriver driver;
		private Map<String, Object> vars;
		private JavascriptExecutor js;
		
		@Before
		public void before() {
	    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Downloads\\chromedriver_win32\\chromedriver.exe");
	    	driver = new ChromeDriver();
	    	js = (JavascriptExecutor) driver;
	    	
	    	driver.get("http://localhost:8080/hibernate_validation_dao/");
	    	driver.manage().window().maximize();
	    	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		}

		 @Test
		 public void the_user_navigates_to_the_store_page() throws Throwable {
		    	System.out.println("User navigates to store page");
		    	String actual = driver.getTitle();
		    	String expected = "Log In";
		    	assertEquals(actual, expected);
		    	driver.close();
		    }
		 
		@Test
		public void the_user_authenticates_to_the_login_page() throws Throwable {
			driver.findElement(By.id("username")).sendKeys("user1");
			driver.findElement(By.id("password")).sendKeys("pass1");
			driver.findElement(By.xpath("//input[@type='submit']")).click();
			String actual = driver.getTitle();
			System.out.println("Window Title" + actual);
			String expected = "SearchOptions";
			assertEquals(actual, expected);
			driver.findElement(By.linkText("logout")).click();
			driver.close();
		}
		
		//regression testcase for region 
		@Test
		public void the_user_navigates_to_region_page() {
			driver.findElement(By.id("username")).sendKeys("user1");
			driver.findElement(By.id("password")).sendKeys("pass1");
			driver.findElement(By.xpath("//input[@type='submit']")).click();
			driver.findElement(By.linkText("Region")).click();
			String actual = driver.getTitle();
			String expected = "Region";
			assertEquals(actual, expected);
			int rowSize = driver.findElements(By.tagName("a")).size();
			assertEquals(rowSize, 8);
			assertFalse(driver.findElements(By.linkText("North Indian")).contains("North Indian"));
			driver.findElement(By.linkText("North Indian")).click();
			assertFalse(driver.findElements(By.tagName("h1")).contains("North Indian"));
			assertFalse(driver.findElements(By.tagName("td")).contains("Pav Bhaji"));
			driver.findElement(By.linkText("logout")).click();
			driver.close();
		}
		
		//regression testcase for chef 
		@Test
		public void the_user_navigates_to_Chef_page() {
			driver.findElement(By.id("username")).sendKeys("user1");
			driver.findElement(By.id("password")).sendKeys("pass1");
			driver.findElement(By.xpath("//input[@value='Login']")).click(); //relative xpath - one locator with two identifiers: type & value
			driver.findElement(By.linkText("Chef")).click();
			String actual = driver.getTitle();
			String expected = "Chefs";
			assertEquals(actual, expected);
			int rowSize = driver.findElements(By.tagName("a")).size();
			assertEquals(rowSize, 12);
			assertFalse(driver.findElements(By.linkText("Ferdousi Begum(B)")).contains("Ferdousi Begum(B)"));
			driver.findElement(By.linkText("Ferdousi Begum(B)")).click();
			assertFalse(driver.findElements(By.tagName("h1")).contains("Ferdousi Begum(B)"));
			assertFalse(driver.findElements(By.tagName("td")).contains("Kalo Bhuna"));
			driver.findElement(By.linkText("logout")).click();
			driver.close();
		}
		
	}

