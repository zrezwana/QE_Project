package com.perscholas.hibernate_validation_dao;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PerScholasTest {
	private static WebDriver driver;
	private static WebDriverWait wait;
	
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 10);
	}
	@AfterClass
	public static void shutDown() {
	driver.close();
	}
	
	@Test
	public void test_CSS_Selector() {
			
	driver.get("https://perscholas.org");
	WebElement cities = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/header/nav[1]/div/ul/li[2]/a")));
    cities.click();
    
    WebElement location = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/header/div[1]/div/div/div/div[1]/ul/li[6]/a")));
    location.click();
    
    WebElement about = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"header\"]/nav[1]/div/div[2]/ul/li[1]/a")));
    about.click();
    
    WebElement staff = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/main/div[2]/div/div/div[2]/section[4]/div/div[3]/a")));
    staff.click();
    
    List<WebElement> staffLists= driver.findElements(By.cssSelector("#greater-boston-team > div > div > a > div > hgroup > h5"));
	List<String> staffNames = new ArrayList<String>();
    for(WebElement we : staffLists) {
	    System.out.println(we.getText());
	    staffNames.add(we.getText());
	   }
		assertThat(staffNames, hasItem("Robin Nadeau"));
		assertThat (staffNames, not(hasItem("Jake McIntosh")));
	   }
}

	
