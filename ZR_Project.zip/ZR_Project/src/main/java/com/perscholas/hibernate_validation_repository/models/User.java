package com.perscholas.hibernate_validation_repository.models;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class User {
	
	@Id
	@GeneratedValue
	private Integer userID;
	
	@Size(min=2, max=50,  message="Username must be between 2 and 50 characters long.")
	@NotBlank(message="Username is required.")
	private String username;
	
	@Size(min=2, max=50,  message="Password must be between 2 and 50 characters long.")
	@NotBlank(message="Password is required.")
	private String password;
	
	@Size(min=2, max=50,  message="First Name must be between 2 and 50 characters long.")
	@NotBlank(message="First Name is required.")
	private String firstname;
	
	@Size(min=2, max=50,  message="Last Name must be between 2 and 50 characters long.")
	@NotBlank(message="Last Name is required.")
	private String lastname;
	
	@Email
	@Size(min=2, max=50,  message="Last Name must be between 2 and 50 characters long.")
	@NotBlank(message="Last Name is required.")
	private String email;
	
	private Integer adminFlag;
	
	

	public User() {
		
	}
	
//	public User() {
//		
//		super();
//		this.userID = userID;
//		this.username = username;
//		this.password = password;
//		this.firstname = firstname;
//		this.lastname = lastname;
//		this.email = email;
//		this.adminFlag = adminFlag;
//	}

	public Integer getUserID() {
		return userID;
	}

	public void setUserID(Integer userId) {
		this.userID = userID;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getAdminFlag() {
		return adminFlag;
	}

	public void setAdminFlag(int adminFlag) {
		this.adminFlag = adminFlag;
	}
	
	
		
}
