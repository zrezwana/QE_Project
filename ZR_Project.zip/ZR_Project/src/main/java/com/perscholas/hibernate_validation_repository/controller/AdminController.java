package com.perscholas.hibernate_validation_repository.controller;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Food;
import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.models.User;
import com.perscholas.hibernate_validation_repository.repository.ChefRepository;
import com.perscholas.hibernate_validation_repository.repository.FoodRepository;
import com.perscholas.hibernate_validation_repository.repository.RegionRepository;
import com.perscholas.hibernate_validation_repository.repository.UserRepository;

@Controller
public class AdminController {
		
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	FoodRepository foodRepository;
	
	@Autowired
	ChefRepository chefRepository;
	
	@Autowired
	RegionRepository regionRepository;
	
	
	@GetMapping("/showAdminSignIn")
	public String showSignIn(Model model) throws SQLException {	
		model.addAttribute("user", new User());
		return "AdminSignIn";
	}
	
	@PostMapping("/verifyAdmin")
	public String verifyAdmin(@Valid @ModelAttribute("user") User user, 
			BindingResult result, HttpSession session) 
					throws ClassNotFoundException, SQLException, IOException {
		System.out.println("Verify User Admin");
		
		User foundUser = userRepository.findUserByUsername(user);
		
		Integer flag = 0;
		
        if (foundUser.getAdminFlag() == 1){
			flag = 1;
		}			
		if(Objects.isNull(foundUser)) {
			return "AdminSignIn";
		} else {
			
			if(foundUser.getPassword().equals(user.getPassword())) {
				if(flag == 1) {
					session.setAttribute("username", user.getUsername());
					return "redirect:/returnToViewOptions";
				}
				else {
					return "AdminSignIn";
				}				
			}
			else {
				return "AdminView";
			}
		}
	}
	
	
	
	
	@GetMapping("/addFoodItem")
	public String addFood(@Valid @ModelAttribute("food") Food food, 
						BindingResult result, Model model,HttpSession session) 
						throws ClassNotFoundException, SQLException, IOException {
		String page="AddFoodOptions";
		if (result.hasErrors()) {			
			return "AdminView";
		}			
		
		

		List<Chef> listOfChefs = chefRepository.showAllChefs();
		List<Region> listOfRegions = regionRepository.showAllRegions();
		model.addAttribute("allChefs", listOfChefs);
		model.addAttribute("allRegions", listOfRegions);
		//Integer foodId = foodRepository.addFood(food);
			return page;
		//return "redirect:/returnToViewOptions";
	}
	
	
	@GetMapping("/updateFoodItem/{foodID}")
	public String updateFoodItem(@Valid @ModelAttribute("food") Food food,@PathVariable(value="foodID") Integer foodID, 
						BindingResult result, Model model,HttpSession session) 
						throws ClassNotFoundException, SQLException, IOException {
		String page="Edit";
		if (result.hasErrors()) {			
			return "AdminView";
		}			
		
		
		if(food!=null) {
			food=foodRepository.getFoodByID(foodID);
			model.addAttribute("food",food);
			page="Edit";
		}
		
		List<Chef> listOfChefs = chefRepository.showAllChefs();
		List<Region> listOfRegions = regionRepository.showAllRegions();
		model.addAttribute("allChefs", listOfChefs);
		model.addAttribute("allRegions", listOfRegions);
		//Integer foodId = foodRepository.addFood(food);
			return page;
		//return "redirect:/returnToViewOptions";
	}
	@GetMapping("/deleteFoodItem/{foodID}")
	public String deleteFoodItem( @PathVariable("foodID") Integer foodId,@ModelAttribute("food") Food food,
						BindingResult result, Model model,HttpSession session) 
						throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {			
			return "AdminView";
		}			
		food=foodRepository.getFoodByID(foodId);
		if(food.getFoodID()!=null) {
			foodRepository.deleteFood(food);
		}
		List<Food> allFooditems = foodRepository.showAllFoods();
		model.addAttribute("allFoodItems", allFooditems);
		return "AdminFoodItems";
	}
	
	
	
	
	@PostMapping("/addOrUpdateFoodItemToRepository")
	public String addOrUpdateFoodItemToRepository(@Valid @ModelAttribute("food") Food food,
						BindingResult result, Model model,HttpSession session) 
						throws ClassNotFoundException, SQLException, IOException {
		Integer foodId =0 ;
		if(food.getFoodID()==null) {
			 foodId = foodRepository.addFood(food);
			}
			else {
		       foodRepository.updateFood(food);
			}
		if(foodId!=0) {
		  model.addAttribute("successful", "Added SuccessFully");
		}
		List<Food> allFooditems = foodRepository.showAllFoods();
		model.addAttribute("allFoodItems", allFooditems);
	    return "AdminFoodItems";
	}
	
	
	
	@GetMapping("/showFoodItems")
	public String showFoodItems(@Valid @ModelAttribute("food") Food food, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		List<Food> allFooditems = foodRepository.showAllFoods();
		model.addAttribute("allFoodItems", allFooditems);
		model.addAttribute("food", new Food());
		return "AdminFoodItems";
	}
	
	@GetMapping("/returnToViewOptions")
	public String backToHomepage() {
		return "AdminView";
	}
}

