package com.perscholas.hibernate_validation_repository.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.repository.RegionRepository;

@Repository
public class MariaDB_RegionRepository implements RegionRepository{
	
	@Autowired
	private NamedParameterJdbcTemplate mariaDbJdbcTemplate;

	private final class RegionMapper implements RowMapper<Region> {

		@Override
		public Region mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Region(rs.getInt(1),rs.getString(2));
		}
	}

	@Override
	public List<Region> showAllRegions() {
		String regionQuery = "SELECT * FROM region";
		List <Region> result = mariaDbJdbcTemplate.query(regionQuery, new RegionMapper());
		return result;
	}

	@Override
	public Region getRegionByID(Integer id) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("id", id);
		String selectRegion = "SELECT * FROM region WHERE regionID= :id";
		List <Region> result = mariaDbJdbcTemplate.query(selectRegion, params, new RegionMapper());
		return result.get(0);
	}
}
