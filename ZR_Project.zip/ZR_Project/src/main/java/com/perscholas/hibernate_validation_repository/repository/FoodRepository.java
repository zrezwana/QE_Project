package com.perscholas.hibernate_validation_repository.repository;

import java.util.List;

import com.perscholas.hibernate_validation_repository.models.Food;

public interface FoodRepository {

	List<Food> showAllFoods();
	Food getFoodByID(Integer id);
	Integer addFood(Food food);
	void deleteFood(Food food);
	Integer updateFood(Food food);
}
