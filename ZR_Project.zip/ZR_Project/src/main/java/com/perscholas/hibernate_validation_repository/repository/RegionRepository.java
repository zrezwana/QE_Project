package com.perscholas.hibernate_validation_repository.repository;

import java.util.List;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Region;

public interface RegionRepository {

	List<Region> showAllRegions();
	Region getRegionByID(Integer id); 

}

